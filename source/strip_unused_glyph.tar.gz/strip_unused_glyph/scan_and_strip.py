#!/usr/bin/python3

translation_dir = "../tl/japanese"
font_old = "../VL-Gothic-Regular.ttf"
font_new = "../VL-Gothic-Regular-strip.ttf"

files = [
"common.rpy",
"demo_character.rpy",
"demo_dynamic.rpy",
"demo_imageops.rpy",
"demo_layers.rpy",
"demo_minigame.rpy",
"demo_nvlmode.rpy",
"demo_persistent.rpy",
"demo_text.rpy",
"demo_transform.rpy",
"demo_transitions.rpy",
"demo_ui.rpy",
"screens.rpy",
"script.rpy",
"tutorial_atl.rpy",
"tutorial_playing.rpy",
"tutorial_quickstart.rpy",
"tutorial_sprite.rpy",
"tutorial_video.rpy",
]

charmap = []

cmdline = ["./strip_glyphs.pe", font_old, font_new, "u0000:u00FF"]

for fname in files:
	rpyfile = translation_dir + "/" + fname
	f = open(rpyfile, "r")
	for l in f:
		for c in l[:-1]:
			code = ord(c)
			if code > 255 and not code in charmap:
				charmap.append(code)
	f.close()

charmap.sort()
for c in charmap:
	cmdline.append("u%04x" % c)
	
import subprocess
subprocess.call(cmdline)

