# generated from '/System/Library/Frameworks/DiscRecording.framework'
import objc as _objc


