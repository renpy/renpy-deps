# generated from '/System/Library/Frameworks/CoreData.framework'
import objc as _objc


