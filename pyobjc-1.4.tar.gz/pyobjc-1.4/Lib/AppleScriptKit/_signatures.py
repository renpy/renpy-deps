# This file is generated using the Signatures tool, don't edit
from objc import setSignatureForSelector
# end of file
