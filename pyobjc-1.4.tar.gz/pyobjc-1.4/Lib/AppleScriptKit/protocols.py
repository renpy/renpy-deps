# generated from '/System/Library/Frameworks/AppleScriptKit.framework'
import objc as _objc


