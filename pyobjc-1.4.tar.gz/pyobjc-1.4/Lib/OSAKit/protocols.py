# generated from '/System/Library/Frameworks/OSAKit.framework'
import objc as _objc


