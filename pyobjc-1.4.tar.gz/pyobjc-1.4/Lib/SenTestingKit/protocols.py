# generated from '/System/Library/Frameworks/SenTestingKit.framework'
import objc as _objc


