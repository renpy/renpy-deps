# This file is generated using the Signatures tool, don't edit
from objc import setSignatureForSelector
setSignatureForSelector('QTMovie', 'initWithError:', '@@:o^@')
# end of file
