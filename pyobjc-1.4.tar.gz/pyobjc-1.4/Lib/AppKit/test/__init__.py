"""AppKit test suite."""
