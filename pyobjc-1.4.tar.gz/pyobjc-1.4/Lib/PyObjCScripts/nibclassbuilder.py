from PyObjCTools.NibClassBuilder import commandline
commandline()
