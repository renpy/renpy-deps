# This file is generated using the Signatures tool, don't edit
from objc import setSignatureForSelector
setSignatureForSelector('ABAddressBook', 'nts_AddTable:withPropertiesAndTypes:needsReadWriteMode:registerDataTypes:neededRegistering:', 'c@:@@cco^c')
setSignatureForSelector('ABAuthenticationInfo', 'appliesToRequest:', 'c@:@')
setSignatureForSelector('ABAuthenticationInfo', 'applyToRequest:', 'c@:@')
setSignatureForSelector('ABDAVManager', 'canReachDotMacError:', 'c@:o^@')
setSignatureForSelector('ABDAVQuery', 'buildRequest', '@@:')
setSignatureForSelector('ABDBCache', 'databaseChangedForUserInfo:groupsChanged:peopleChanged:', 'v@:@o^co^c')
setSignatureForSelector('ABFileManager', 'ACLsAtURL:read:write:', 'c@:@o^@o^@')
setSignatureForSelector('ABFileManager', 'dictionaryAtURL:errorCode:securely:', '@@:@o^ic')
setSignatureForSelector('ABGroupsController', 'sharingProgressForGroup:showUpdateSharingIndicator:', 'f@:@o^c')
setSignatureForSelector('ABPerson', 'encodedDataForValue:charsetName:', '@@:@o^@')
setSignatureForSelector('ABSearchElementHelper', 'calculateBestDateType:andBestValue:forTimeInterval:', 'v@:o^io^dd')
setSignatureForSelector('ABSearchElementHelper', 'isSingleSearchElement:property:value:comparison:level:', 'c@:@o^@o^@o^ii')
# end of file
