import MyDocument
import Note

from PyObjCTools import AppHelper

if __name__ == "__main__":
    AppHelper.runEventLoop()
