#!/usr/bin/env python
"""
Quickie script to update the services
"""
import AppKit
AppKit.NSUpdateDynamicServices()
