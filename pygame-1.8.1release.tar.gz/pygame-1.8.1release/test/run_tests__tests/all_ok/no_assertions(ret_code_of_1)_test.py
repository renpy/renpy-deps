import test_utils
import test.unittest as unittest

class KeyModuleTest(unittest.TestCase):
    def test_get_focused(self):
        pass

    def test_get_mods(self):
        pass

    def test_get_pressed(self):
        pass

    def test_name(self):
        pass

    def test_set_mods(self):
        pass

    def test_set_repeat(self):
        pass

if __name__ == '__main__':
    unittest.main()