#################################### IMPORTS ###################################

import test_utils
import test.unittest as unittest
from test_utils import test_not_implemented

################################################################################

class SysfontModuleTest(unittest.TestCase):
    def test_create_aliases(self):

        # __doc__ (as of 2008-06-25) for pygame.sysfont.create_aliases:

          # 

        self.assert_(test_not_implemented()) 

    def test_initsysfonts(self):

        # __doc__ (as of 2008-06-25) for pygame.sysfont.initsysfonts:

          # 

        self.assert_(test_not_implemented()) 

    def test_initsysfonts_darwin(self):

        # __doc__ (as of 2008-06-25) for pygame.sysfont.initsysfonts_darwin:

          # 

        self.assert_(test_not_implemented()) 

    def test_initsysfonts_unix(self):

        # __doc__ (as of 2008-06-25) for pygame.sysfont.initsysfonts_unix:

          # 

        self.assert_(test_not_implemented()) 

    def test_initsysfonts_win32(self):

        # __doc__ (as of 2008-06-25) for pygame.sysfont.initsysfonts_win32:

          # 

        self.assert_(test_not_implemented())

################################################################################

if __name__ == '__main__':
    unittest.main()
