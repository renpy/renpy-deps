######################### PYGAME UNITTEST STUBBER TESTS ########################
"""

TODO
====

tests for new stubber: deleted tests for missing units

"""

import pygame, unittest, gen_stubs


################################################################################